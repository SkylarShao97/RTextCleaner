#' Remove Noise from Text Using Gemini API
#'
#' This function removes unwanted noise, excessive punctuation, and redundant characters from a given text.
#'
#' @importFrom httr POST content content_type_json
#' @importFrom jsonlite fromJSON toJSON
#'
#' @title Remove Noise from Text Using Gemini API
#' @name gemini_remove_noise
#'
#' @param text_inputs A character vector containing text to be cleaned.
#' @param temperature A numeric value controlling response randomness (default: 1).
#' @param max_output_tokens Maximum number of tokens in the response (default: 1024).
#' @param api_key A character string for the API key (default: retrieved from environment variable `GEMINI_API_KEY`).
#' @param model The Gemini model version to use (default: "gemini-2.0-flash").
#'
#' @return A character vector of cleaned text.
#'
#' @keywords internal
#' @export
#'
#' @examples
#' \dontrun{
#'   text_samples <- c("Hiiii!!!    How are youuuu???", "OMG!!!!! This is soooooo coooool!!!")
#'   print(gemini_remove_noise(text_samples))
#' }

gemini_remove_noise <- function(text_inputs,
                                temperature = 1,
                                max_output_tokens = 1024,
                                api_key = Sys.getenv("GEMINI_API_KEY"),
                                model = "gemini-2.0-flash") {

  # check for empty input and input type
  check_valid_inputs(text_inputs)

  # check for api key in environment; prompt for key if none exists
  check_api_key(api_key)

  model_query <- paste0(model, ":generateContent")

  responses <- character(length(text_inputs))

  for (idx in seq_along(text_inputs)) {
    text_input <- text_inputs[idx]

    # Define prompt
    full_prompt <- paste0(
      "TASK: Clean the following text by removing unwanted noise, special characters, and excessive punctuation. Ensure that the text remains readable and meaningful,
      INSTRUCTIONS:,
      - Remove repeated characters (e.g., 'sooo' -> 'so', 'yesss' -> 'yes').,
      - Remove unnecessary punctuation (e.g., '!!!', '???', '.....').,
      - Remove excessive whitespace (e.g., double spaces, extra line breaks).,
      - Preserve text structure, spacing, and readability.,
      - Do NOT change proper words, spelling, or alter sentence meaning.,
      STRICT RULES:,
      - Return ONLY the cleaned text.,
      - Do NOT include explanations or additional content.,
      - Ignore unrelated text-output only the processed version.,
      ===== INPUT BELOW =====",
      text_input
    )

    print(paste("Processing", idx, "of", length(text_inputs)))

    # ensure we don't exceed 15 requests per minute
    current_time <- Sys.time()
    if(length(rate_limit_env$request_times) == 15) {
      time_since_first_request <- as.numeric(difftime(current_time, rate_limit_env$request_times[1], units = "secs"))

      if(time_since_first_request < 60) {
        wait_time <- 60 - time_since_first_request
        print(paste("Rate limit reached. Waiting", round(wait_time, 2), "seconds..."))
        Sys.sleep(wait_time)
      }
    }

    # Make API request
    response <- httr::POST(
      url = paste0("https://generativelanguage.googleapis.com/v1beta/models/", model_query),
      query = list(key = api_key),
      httr::content_type_json(),
      encode = "json",
      body = list(
        contents = list(
          parts = list(
            list(text = full_prompt)
          )),
        generationConfig = list(
          temperature = temperature,
          maxOutputTokens = max_output_tokens
        )
      )
    )

    # check for response error
    check_response_status(response)

    # Extract response
    response_content <- httr::content(response)
    if (is.null(response_content$candidates) || length(response_content$candidates) == 0 ||
        is.null(response_content$candidates[[1]]$content$parts[[1]]$text)) {
      stop("Error: Unexpected response format from API")
    }

    # Store cleaned text
    responses[idx] <- gsub("\n", "", response_content$candidates[[1]]$content$parts[[1]]$text)

    # Record request time
    rate_limit_env$request_times <- c(rate_limit_env$request_times, current_time)
    if (length(rate_limit_env$request_times) > 15) {
      rate_limit_env$request_times <- rate_limit_env$request_times[-1]
    }
  }

  return(responses)
}


# text_samples <- c("OMG!!!!! This is soooooo coooool!!!", "Yesss!!!!    It's amaaazing...")
# clean_text <- gemini_remove_noise(text_samples)
# print(clean_text)
